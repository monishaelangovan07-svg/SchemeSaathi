"""Rule engine: matches a citizen profile to schemes in data/schemes.json."""
import json
from pathlib import Path

DATA_FILE = Path(__file__).parent / "data" / "schemes.json"


def load_schemes(path=DATA_FILE):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def explain(scheme, profile):
    """Return a list of reasons why the profile qualifies, or None if it does not."""
    reasons = []
    age, gender = profile["age"], profile["gender"]
    occupation, income = profile["occupation"], profile["income"]

    if "min_age" in scheme:
        if age < scheme["min_age"]:
            return None
        reasons.append(f"Age {age} meets minimum age {scheme['min_age']}")
    if "max_age" in scheme:
        if age > scheme["max_age"]:
            return None
        reasons.append(f"Age {age} is within the maximum age {scheme['max_age']}")
    if "genders" in scheme:
        if gender not in scheme["genders"]:
            return None
        reasons.append("Scheme is for " + "/".join(scheme["genders"]))
    if "occupations" in scheme:
        if occupation not in scheme["occupations"]:
            return None
        reasons.append(f"Occupation '{occupation}' is covered")
    if "max_income" in scheme:
        if income > scheme["max_income"]:
            return None
        reasons.append(f"Income is within Rs {scheme['max_income']:,} per year")
    return reasons or ["Open to all citizens"]


def check(profile, schemes=None):
    """Return the schemes this profile is eligible for, each with its reasons."""
    schemes = schemes if schemes is not None else load_schemes()
    results = []
    for s in schemes:
        reasons = explain(s, profile)
        if reasons is not None:
            results.append({**s, "reasons": reasons})
    return results


def validate(data):
    """Validate raw JSON input; return (profile, error)."""
    try:
        profile = {
            "age": int(data["age"]),
            "gender": str(data["gender"]).lower(),
            "occupation": str(data["occupation"]).lower(),
            "income": int(data["income"]),
        }
    except (KeyError, TypeError, ValueError):
        return None, "Please fill all fields with valid values."
    if not 0 <= profile["age"] <= 120 or profile["income"] < 0:
        return None, "Age or income is out of range."
    if profile["gender"] not in ("male", "female", "other"):
        return None, "Invalid gender."
    return profile, None
