# Technical Design Document

## Overview
SchemeSaathi is a small client-server app. The browser sends the user's answers to a Flask
API, which runs a rule engine over a JSON scheme list and returns matches with reasons.

## Architecture diagram
```mermaid
flowchart LR
    U[User browser<br/>HTML/CSS/JS form] -->|POST /api/check JSON| A[Flask app.py]
    A --> V[engine.validate]
    V --> E[engine.check<br/>rule engine]
    D[(data/schemes.json)] --> E
    E -->|matches + reasons| A
    A -->|JSON| U
```

## Components
| Component | Responsibility |
|---|---|
| `templates/index.html`, `static/` | Form and results page |
| `app.py` | Routes: `/` and `/api/check` |
| `engine.py` | Input validation and eligibility rules |
| `data/schemes.json` | Scheme details and eligibility criteria |

## Rule format
Each scheme may define `min_age`, `max_age`, `genders`, `occupations`, `max_income`.
A missing key means "no restriction". A scheme matches only if every present rule passes.

## Privacy
No database, no login. User answers are used for one request and never stored.

## Testing
`tests/test_engine.py` covers rule logic, validation and the API.
