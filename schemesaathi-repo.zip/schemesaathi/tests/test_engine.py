import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import engine  # noqa: E402
from app import app  # noqa: E402


def profile(**kw):
    base = {"age": 30, "gender": "female", "occupation": "worker", "income": 100000}
    return {**base, **kw}


def ids(p):
    return {s["id"] for s in engine.check(p)}


def test_farmer_gets_pm_kisan():
    assert "pm-kisan" in ids(profile(occupation="farmer"))


def test_non_farmer_does_not_get_pm_kisan():
    assert "pm-kisan" not in ids(profile(occupation="student"))


def test_high_income_excluded_from_pmjay():
    assert "pmjay" not in ids(profile(income=900000))


def test_senior_pension_needs_age_60():
    assert "ignoaps" not in ids(profile(age=45))
    assert "ignoaps" in ids(profile(age=65, income=50000))


def test_girl_child_gets_sukanya():
    assert "ssy" in ids(profile(age=5, gender="female", occupation="student"))


def test_reasons_are_returned():
    for s in engine.check(profile(occupation="farmer")):
        assert s["reasons"]


def test_validate_rejects_bad_input():
    _, err = engine.validate({"age": "abc"})
    assert err


def test_api_ok_and_error():
    c = app.test_client()
    r = c.post("/api/check", json={"age": 40, "gender": "male", "occupation": "farmer", "income": 90000})
    assert r.status_code == 200 and r.get_json()["count"] > 0
    assert c.post("/api/check", json={}).status_code == 400
