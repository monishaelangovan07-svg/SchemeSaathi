const $ = (id) => document.getElementById(id);

function el(tag, text, cls) {
  const e = document.createElement(tag);
  if (text) e.textContent = text;
  if (cls) e.className = cls;
  return e;
}

function show(schemes) {
  const box = $("results");
  box.innerHTML = "";
  if (!schemes.length) { box.textContent = "No matching schemes found."; return; }
  box.append(el("h2", `You may qualify for ${schemes.length} scheme(s)`));
  for (const s of schemes) {
    const d = el("div", "", "scheme");
    const a = el("a", "Official site");
    a.href = s.link; a.target = "_blank"; a.rel = "noopener";
    d.append(
      el("h3", s.name), el("p", s.benefit),
      el("p", "Why: " + s.reasons.join("; "), "why"),
      el("p", "Documents: " + s.documents.join(", ")),
      el("p", "How to apply: " + s.how_to_apply), a
    );
    box.append(d);
  }
}

$("go").addEventListener("click", async () => {
  $("error").textContent = "";
  const body = {
    age: $("age").value, gender: $("gender").value,
    occupation: $("occupation").value, income: $("income").value,
  };
  const res = await fetch("/api/check", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) { $("error").textContent = data.error; return; }
  show(data.schemes);
});
