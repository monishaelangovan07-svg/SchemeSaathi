# SchemeSaathi

A simple web app that helps citizens find government welfare schemes they qualify for.
Built for **Hack for Social Cause** - Theme: **Digital Inclusion**.

## Problem
Many people, especially first-time internet users, miss welfare schemes because the
information is scattered, full of jargon, and hard to check.

## Solution
Answer 4 simple questions (age, gender, occupation, family income). SchemeSaathi shows
the schemes you may qualify for, **why** you qualify, the documents needed, how to apply,
and the official link. No login, no personal data stored.

## Features
- Mobile-friendly, plain-language form
- Transparent rule-based matching (every result shows its reasons)
- Scheme data kept in one editable JSON file - easy to extend
- REST API (`POST /api/check`)
- Automated tests

## Tech stack
Python 3, Flask, HTML/CSS/JavaScript, JSON, pytest

## Setup
```bash
git clone <your-repo-url>
cd schemesaathi
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser.

**Environment variables:** none required.

## Run tests
```bash
pytest
```

## API
`POST /api/check`
```json
{"age": 40, "gender": "male", "occupation": "farmer", "income": 90000}
```
Returns `{"count": N, "schemes": [...]}`; each scheme includes `reasons`.

## Project structure
```
app.py               Flask routes
engine.py            Rule engine (eligibility logic)
data/schemes.json    Sample scheme data
templates/ static/   Frontend
tests/               Test cases
docs/ARCHITECTURE.md Technical design document
```

## Sample data
`data/schemes.json` has 11 sample central schemes with simplified rules. To add a scheme,
add an entry with optional keys: `min_age`, `max_age`, `genders`, `occupations`, `max_income`.

## Disclaimer
Eligibility rules are simplified and indicative. Always confirm on the official website
before applying. Scheme details change; check https://www.myscheme.gov.in for updates.

## Future scope
Regional languages (Tamil, Hindi), voice input, state-specific schemes, SMS/WhatsApp access
through Common Service Centres.

## License
MIT - see [LICENSE](LICENSE).

## Authors
Monisha E, Tashmita M
