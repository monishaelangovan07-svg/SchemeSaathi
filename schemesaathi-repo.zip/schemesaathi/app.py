from flask import Flask, jsonify, render_template, request

import engine

app = Flask(__name__)


@app.get("/")
def home():
    return render_template("index.html")


@app.post("/api/check")
def api_check():
    profile, error = engine.validate(request.get_json(silent=True) or {})
    if error:
        return jsonify({"error": error}), 400
    schemes = engine.check(profile)
    return jsonify({"count": len(schemes), "schemes": schemes})


if __name__ == "__main__":
    app.run(debug=True)
